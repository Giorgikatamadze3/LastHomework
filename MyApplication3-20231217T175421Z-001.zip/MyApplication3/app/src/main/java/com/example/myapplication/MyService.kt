package com.example.myapplication

import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.os.IBinder
import androidx.core.app.NotificationCompat
import java.util.Timer
import java.util.TimerTask

class MyService : Service() {

    override fun onBind(intent: Intent): IBinder {
        TODO("Return the communication channel to the service.")
    }

    override fun onCreate() {
        super.onCreate()

        val timer = Timer();
        timer.scheduleAtFixedRate(object : TimerTask(){
            override fun run() {
                sendNotification()
            }
        },0,10*60*1000)
    }

    private fun sendNotification() {
        val builder = NotificationCompat.Builder(this)
            .setContentTitle("Service Notification")
            .setContentText("This notification was sent from a service.")
            .setSmallIcon(R.drawable.ic_notification)
            .setAutoCancel(true)

        // Create an intent that will stop the service when the user clicks on the notification
        val stopIntent = Intent(this, MyService::class.java)
        stopIntent.action = ACTION_STOP_SERVICE
        val stopPendingIntent = PendingIntent.getService(this, 0, stopIntent, PendingIntent.FLAG_UPDATE_CURRENT)

        // Add the pending intent to the notification
        builder.addAction(R.drawable.ic_stop, "Stop Service", stopPendingIntent)

        // Send the notification
        val notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        notificationManager.notify(1, builder.build())
    }
}